#include <jni.h>
#include <string>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <thread>
#include <mutex>

#define PORT_NUMBER       55500
#define DATA_BUFFER_SIZE  2048

int socketAtClientSide = 0;
char dataBuffer[DATA_BUFFER_SIZE];
char receiveBuffer[DATA_BUFFER_SIZE];
bool fieldDeviceIsInProblem = false;

std::thread receiveThread;
std::mutex resouceLock;

void CheckIfDataReceivedFromServer(void)
{
  recv(socketAtClientSide, receiveBuffer, sizeof(receiveBuffer), 0);
  if(receiveBuffer[0] != 0)
  {
    if(strcmp(receiveBuffer, "ERROR") == 0)
    {
      resouceLock.lock();
      fieldDeviceIsInProblem = true;
      resouceLock.unlock();
    }
  }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_basavarajubv_androidclient_AndroidClient_Initialise(JNIEnv* env, jobject /*this*/)
{
  struct sockaddr_in serverAddress;

  socketAtClientSide = socket(AF_INET, SOCK_STREAM, 0);
  if(socketAtClientSide < 0)
  {
    return env->NewStringUTF("Problem while Creating Socket");
  }

  memset(dataBuffer, 0, DATA_BUFFER_SIZE);

  memset(&serverAddress, 0, sizeof(sockaddr_in));
  serverAddress.sin_family = AF_INET;
  serverAddress.sin_port = htons(PORT_NUMBER);
  serverAddress.sin_addr.s_addr = inet_addr("159.99.104.30");

  int errorCode = connect(socketAtClientSide, (struct sockaddr *)&serverAddress, sizeof(serverAddress));
  if (errorCode< 0)
  {
    return env->NewStringUTF("Connection Error");
  }

  std::thread temp(CheckIfDataReceivedFromServer);

  receiveThread.swap(temp);

  return env->NewStringUTF("Connected to Server");
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_basavarajubv_androidclient_AndroidClient_SendData(JNIEnv* env, jobject caller, jstring dataToSend)
{
  if(socketAtClientSide > 0)
  {
    std::string data = std::string(env->GetStringUTFChars(dataToSend, NULL));
    send(socketAtClientSide, data.c_str(), strlen(data.c_str()), 0);
  }

  return;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_basavarajubv_androidclient_AndroidClient_CheckForErrorMsg(JNIEnv* env, jobject caller)
{
  jboolean errorDetected = false;
  resouceLock.lock();
  if(fieldDeviceIsInProblem)
  {
    errorDetected = true;
    fieldDeviceIsInProblem = false;

    receiveThread.join();

    std::thread temp(CheckIfDataReceivedFromServer);
    receiveThread.swap(temp);
  }
  resouceLock.unlock();

  return errorDetected;
}

