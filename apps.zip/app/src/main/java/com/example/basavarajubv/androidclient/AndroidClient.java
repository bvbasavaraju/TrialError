package com.example.basavarajubv.androidclient;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class AndroidClient extends AppCompatActivity
{
  // Used to load the 'native-lib' library on application startup.
  static
  {
    System.loadLibrary("native-lib");
  }

  /**
   * A native method that is implemented by the 'native-lib' native library,
   * which is packaged with this application.
   */
  public native String Initialise();
  public native void SendData(String data);
  public native boolean CheckForErrorMsg();

  //Variable and Members of this activity
  private final int AGE_GROUP_0_TO_6 = 1;
  private final int AGE_GROUP_7_TO_12 = 2;
  private final int AGE_GROUP_13_TO_17 = 3;
  private final int AGE_GROUP_18_PLUS = 4;

  private final int TOTAL_NUMBER_OF_QUESTIONS = 5; //TODO: Update it with total number of questions in each group
  private final String[] questionsAgeGroup1 = {
    "Question1",
    "Question2",
    "Question3",
    "Question4",
    "Question5"
  };

  private final String[][] optionsAgeGroup1 = {
    {"Q1Option1", "Q1Option2", "Q1Option3", "Q1Option4"},
    {"Q2Option1", "Q2Option2", "Q2Option3", "Q2Option4"},
    {"Q3Option1", "Q3Option2", "Q3Option3", "Q3Option4"},
    {"Q4Option1", "Q4Option2", "Q4Option3", "Q4Option4"},
    {"Q5Option1", "Q5Option2", "Q5Option3", "Q5Option4"}
  };

  private String contestantName = "";
  private int ageGroup = 0;
  private int[] currentQuestionIndexes = {0, 0, 0, 0, 0};
  private int[] correctAnswerIndex = {0, 0, 0, 0, 0};

  private int answerSelected = 0;

  boolean errorDetected = false;
  boolean connectedToServer = false;
  @Override
  protected void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_android_client);

    ConnectToServer();

    Button buttonAgeGroup1 = (Button) findViewById(R.id.buttonAgeGroup1);
    buttonAgeGroup1.setOnClickListener(new View.OnClickListener()
    {
      @Override
      public void onClick(View v)
      {
        MoveToQuestionsLayout(AGE_GROUP_0_TO_6);
      }
    });

    Button buttonAgeGroup2 = (Button) findViewById(R.id.buttonAgeGroup2);
    buttonAgeGroup2.setOnClickListener(new View.OnClickListener()
    {
      @Override
      public void onClick(View v)
      { MoveToQuestionsLayout(AGE_GROUP_7_TO_12);
      }
    });

    Button buttonAgeGroup3 = (Button) findViewById(R.id.buttonAgeGroup3);
    buttonAgeGroup3.setOnClickListener(new View.OnClickListener()
    {
      @Override
      public void onClick(View v)
      { MoveToQuestionsLayout(AGE_GROUP_13_TO_17);
      }
    });

    Button buttonAgeGroup4 = (Button) findViewById(R.id.buttonAgeGroup4);
    buttonAgeGroup4.setOnClickListener(new View.OnClickListener()
    {
      @Override
      public void onClick(View v)
      { MoveToQuestionsLayout(AGE_GROUP_18_PLUS);
      }
    });
  }

  protected void MoveToQuestionsLayout(int ageGroup_)
  {
    if(!CheckForErrorMsg())
    {
      return;
    }

    TextView textFieldDeviceHealth = (TextView) findViewById(R.id.textFieldDeviceHealth);
    textFieldDeviceHealth.setText("Field Device Health: ERROR");

    EditText textName = (EditText) findViewById(R.id.textName);

    if(textName.getText().length() == 0)
    {
      Toast.makeText(getApplicationContext(),"Age group is not selected",Toast.LENGTH_LONG);
      return;
    }
    else
    {
      contestantName = textName.getText().toString();
      Toast.makeText(getApplicationContext(),contestantName,Toast.LENGTH_LONG);
    }

    if(ageGroup_ != 0)
    {
      ageGroup = ageGroup_;
      if(connectedToServer)
      {
        //TODO: This should be called only after solution
        SendMsg("solved");
      }
      PickRandomQuestion();
      //TODO: Move to question Layout
    }
    else
    {
      Toast.makeText(getApplicationContext(),"Age group is not selected",Toast.LENGTH_LONG);
      return;
    }
  }

  protected void ConnectToServer()
  {
    if(!connectedToServer)
    {
      String successMsg = "Connected to Server";
      String status = Initialise();

      if (status.compareTo(successMsg) == 0)
      {
        connectedToServer = true;
      }
    }
  }

  protected void PickRandomQuestion()
  {
    /*int count = 5;

    for (int i = 0; i < 5; i++)
    {
      int questionIndex = new Random().nextInt(TOTAL_NUMBER_OF_QUESTIONS);
      currentQuestionIndexes
    }*/
    int count = 5;

    int questionIndex = new Random().nextInt(TOTAL_NUMBER_OF_QUESTIONS);
    for (int i = 0; i < count; i ++)
    {
      int index = questionIndex + i;
      if(index >= TOTAL_NUMBER_OF_QUESTIONS)
      {
        index = index - TOTAL_NUMBER_OF_QUESTIONS;
      }
      currentQuestionIndexes[i] = index;
      correctAnswerIndex[i] = new Random().nextInt(4);  // TODO: Get the actual Answers
    }
  }

  protected void SendMsg(String data)
  {
    SendData(data);

    TextView textFieldDeviceHealth = (TextView) findViewById(R.id.textFieldDeviceHealth);
    textFieldDeviceHealth.setText("Field Device Health: Normal");
  }
}
