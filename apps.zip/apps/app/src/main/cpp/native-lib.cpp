#include <jni.h>
#include <string>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <thread>
#include <mutex>

#define PORT_NUMBER       55500
#define DATA_BUFFER_SIZE  256

int socketAtClientSideForOscGsm = 0;
char dataBufferOscGsm[DATA_BUFFER_SIZE];

int socketAtClientSideForOpcUaServer = 0;
char dataBufferOpcUaServer[DATA_BUFFER_SIZE];

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_basavarajubv_androidclient_AndroidClient_ConnectToOscGsm(JNIEnv* env, jobject /*this*/)
{
  struct sockaddr_in serverAddress;

  socketAtClientSideForOscGsm = socket(AF_INET, SOCK_STREAM, 0);
  if(socketAtClientSideForOscGsm < 0)
  {
    return env->NewStringUTF("Problem while Creating Socket");
  }

  memset(dataBufferOscGsm, 0, DATA_BUFFER_SIZE);

  memset(&serverAddress, 0, sizeof(sockaddr_in));
  serverAddress.sin_family = AF_INET;
  serverAddress.sin_port = htons(PORT_NUMBER);
  serverAddress.sin_addr.s_addr = inet_addr("159.99.104.30");

  int errorCode = connect(socketAtClientSideForOscGsm, (struct sockaddr *)&serverAddress, sizeof(serverAddress));
  if (errorCode< 0)
  {
    return env->NewStringUTF("Connection Error");
  }

  return env->NewStringUTF("Connected to Server");
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_basavarajubv_androidclient_AndroidClient_ConnectToOpcUaServer(JNIEnv* env, jobject /*this*/)
{
  struct sockaddr_in serverAddress;

  socketAtClientSideForOpcUaServer = socket(AF_INET, SOCK_STREAM, 0);
  if(socketAtClientSideForOpcUaServer < 0)
  {
    return env->NewStringUTF("Problem while Creating Socket");
  }

  memset(dataBufferOpcUaServer, 0, DATA_BUFFER_SIZE);

  memset(&serverAddress, 0, sizeof(sockaddr_in));
  serverAddress.sin_family = AF_INET;
  serverAddress.sin_port = htons(PORT_NUMBER);
  serverAddress.sin_addr.s_addr = inet_addr("159.99.104.50");

  int errorCode = connect(socketAtClientSideForOpcUaServer, (struct sockaddr *)&serverAddress, sizeof(serverAddress));
  if (errorCode< 0)
  {
    return env->NewStringUTF("Connection Error");
  }

  return env->NewStringUTF("Connected to Server");
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_basavarajubv_androidclient_AndroidClient_SendData(JNIEnv* env, jobject caller, jstring dataToSend)
{
  if(socketAtClientSideForOscGsm > 0)
  {
    std::string data = std::string(env->GetStringUTFChars(dataToSend, NULL));
    send(socketAtClientSideForOscGsm, data.c_str(), strlen(data.c_str()), 0);
  }

  if(socketAtClientSideForOpcUaServer > 0)
  {
    std::string data = std::string(env->GetStringUTFChars(dataToSend, NULL));
    send(socketAtClientSideForOpcUaServer, data.c_str(), strlen(data.c_str()), 0);
  }

  return;
}

