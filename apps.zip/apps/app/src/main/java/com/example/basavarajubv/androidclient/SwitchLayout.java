package com.example.basavarajubv.androidclient;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SwitchLayout extends AppCompatActivity
{

  //Variable and Members of this activity
  private final int SWITCH_BENGALURU_EYE    = 1;
  private final int SWITCH_SHIP_IN_CYCLONE  = 2;
  private final int SWITCH_SKY_SCREAMER     = 3;
  private final int SWITCH_ASTRO_ORBITER    = 4;
  private final int SWITCH_GALAXY_OF_LIGHTS = 5;

  public static final String SELECTED_SWITCH_KEY = "com.example.basavarajubv.androidclient.SELECTED_SWITCH_KEY";
  public static final String AGE_GROUP_KEY = "com.example.basavarajubv.androidclient.AGE_GROUP_KEY";

  private int ageGroup = 0;
  @Override
  protected void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_switch_layout);

    Intent intent = getIntent();
    ageGroup = intent.getIntExtra(AndroidClient.AGE_GROUP_KEY, 0);

    Button buttonSwitch1 = (Button)(findViewById(R.id.buttonSwitch1));
    buttonSwitch1.setOnClickListener(new View.OnClickListener()
    {
      @Override
      public void onClick(View v)
      {
        MoveToCodesLayout(SWITCH_BENGALURU_EYE);
      }
    });

    Button buttonSwitch2 = (Button)(findViewById(R.id.buttonSwitch2));
    buttonSwitch2.setOnClickListener(new View.OnClickListener()
    {
      @Override
      public void onClick(View v)
      {
        MoveToCodesLayout(SWITCH_SHIP_IN_CYCLONE);
      }
    });

    Button buttonSwitch3 = (Button)(findViewById(R.id.buttonSwitch3));
    buttonSwitch3.setOnClickListener(new View.OnClickListener()
    {
      @Override
      public void onClick(View v)
      {
        MoveToCodesLayout(SWITCH_SKY_SCREAMER);
      }
    });

    Button buttonSwitch4 = (Button)(findViewById(R.id.buttonSwitch4));
    buttonSwitch4.setOnClickListener(new View.OnClickListener()
    {
      @Override
      public void onClick(View v)
      {
        MoveToCodesLayout(SWITCH_ASTRO_ORBITER);
      }
    });

    Button buttonSwitch5 = (Button)(findViewById(R.id.buttonSwitch5));
    buttonSwitch5.setOnClickListener(new View.OnClickListener()
    {
      @Override
      public void onClick(View v)
      { MoveToCodesLayout(SWITCH_GALAXY_OF_LIGHTS);
      }
    });
  }

  protected void MoveToCodesLayout(int switchSelected_)
  {
    Intent intent = new Intent(this, CodesLayout.class);
    intent.putExtra(AGE_GROUP_KEY, ageGroup);
    intent.putExtra(SELECTED_SWITCH_KEY, switchSelected_);

    startActivityForResult(intent, 1);
  }

  public void onActivityResult(int requestCode, int resultCode, Intent data)
  {
    setResult(RESULT_OK, data);
    finish();
  }
}
