package com.example.basavarajubv.androidclient;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AndroidClient extends AppCompatActivity
{
  // Used to load the 'native-lib' library on application startup.
  static
  {
    System.loadLibrary("native-lib");
  }

  /**
   * A native method that is implemented by the 'native-lib' native library,
   * which is packaged with this application.
   */
  public native String ConnectToOscGsm();
  public native String ConnectToOpcUaServer();
  public native void SendData(String data);

  //Variable and Members of this activity
  private final int AGE_GROUP_0_TO_6 = 1;
  private final int AGE_GROUP_7_TO_12 = 2;
  private final int AGE_GROUP_13_TO_17 = 3;
  private final int AGE_GROUP_18_PLUS = 4;

  public static final String AGE_GROUP_KEY = "com.example.basavarajubv.androidclient.AgeGroup";

  boolean connectedToServer = false;
  @Override
  protected void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_android_client);

    ConnectToServer();

    Button buttonAgeGroup1 = (Button) findViewById(R.id.buttonAgeGroup1);
    buttonAgeGroup1.setOnClickListener(new View.OnClickListener()
    {
      @Override
      public void onClick(View v)
      { MoveToSelectingSwitchLayout(AGE_GROUP_0_TO_6);
      }
    });

    Button buttonAgeGroup2 = (Button) findViewById(R.id.buttonAgeGroup2);
    buttonAgeGroup2.setOnClickListener(new View.OnClickListener()
    {
      @Override
      public void onClick(View v)
      { MoveToSelectingSwitchLayout(AGE_GROUP_7_TO_12);
      }
    });

    Button buttonAgeGroup3 = (Button) findViewById(R.id.buttonAgeGroup3);
    buttonAgeGroup3.setOnClickListener(new View.OnClickListener()
    {
      @Override
      public void onClick(View v)
      { MoveToSelectingSwitchLayout(AGE_GROUP_13_TO_17);
      }
    });

    Button buttonAgeGroup4 = (Button) findViewById(R.id.buttonAgeGroup4);
    buttonAgeGroup4.setOnClickListener(new View.OnClickListener()
    {
      @Override
      public void onClick(View v)
      { MoveToSelectingSwitchLayout(AGE_GROUP_18_PLUS);
      }
    });
  }

  protected void MoveToSelectingSwitchLayout(int ageGroup_)
  {
    EditText textName = (EditText) findViewById(R.id.textName);

    if(textName.getText().length() == 0)
    {
      Toast.makeText(getApplicationContext(),"Age group is not selected",Toast.LENGTH_LONG);
      return;
    }

    if(ageGroup_ != 0)
    {
      Intent intent = new Intent(this, SwitchLayout.class);
      intent.putExtra(AGE_GROUP_KEY, ageGroup_);
      startActivityForResult(intent, 1);
    }
    else
    {
      Toast.makeText(getApplicationContext(),"Age group is not selected",Toast.LENGTH_LONG);
      return;
    }
  }

  public void onActivityResult(int requestCode, int resultCode, Intent data)
  {
    if(resultCode == RESULT_OK)
    {
      int switchToTurnOn = data.getIntExtra(FinalQuestionActivity.SWITCH_TO_TURN_ON, 0);
      if(switchToTurnOn > 0)
      {
        SendMsg(Integer.toString(switchToTurnOn));
      }
    }
  }

  protected void ConnectToServer()
  {
    if(!connectedToServer)
    {
      String successMsg = "Connected to Server";
      String status1 = ConnectToOscGsm();
      String status2 = ConnectToOpcUaServer();
      if ((status1.compareTo(successMsg) == 0) && (status2.compareTo(successMsg) == 0))
      {
        connectedToServer = true;
      }
    }
  }

  protected void SendMsg(String data)
  {
    SendData(data);
  }
}
