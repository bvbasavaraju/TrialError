package com.example.basavarajubv.androidclient;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class FinalQuestionActivity extends AppCompatActivity
{
  // Used to load the 'native-lib' library on application startup

  protected int aVal = 0;
  protected int bVal = 0;
  protected int cVal = 0;
  protected int dVal = 0;
  protected int eVal = 0;

  int ageGroup = 0;
  int switchSelected = 0;

  public static final String SWITCH_TO_TURN_ON = "com.example.basavarajubv.androidclient.SWITCH_TO_TURN_ON";

  protected final int BIGGEST_NUMBER = 10001;
  protected final int SMALLEST_NUMBER = 10002;
  protected final int BIGGEST_BETWEEN_A_E = 10003;
  protected final int NUMBER_A = 10004;
  protected final int NUMBER_B = 10005;
  protected final int NUMBER_C = 10006;
  protected final int NUMBER_D = 10007;
  protected final int NUMBER_E = 10008;

  final String[] simpleQuestions =
    {
      "Which number is Biggest ?",
      "Which number is Smallest ?",
      "Which number is Biggest between A and E ?",
      "Enter the number A ?",
      "Enter the number B ?",
      "Enter the number C ?",
      "Enter the number D ?",
      "Enter the number E ?",
    };

  final int[] simpleQuestionsInNumber = {BIGGEST_NUMBER, SMALLEST_NUMBER, BIGGEST_BETWEEN_A_E, NUMBER_A, NUMBER_B, NUMBER_C, NUMBER_D, NUMBER_E};

  protected final int A_PLUS_E = 20001;
  protected final int B_PLUS_D = 20002;
  protected final int B_PLUS_27 = 20003;
  protected final int C_MULT_10 = 20004;
  protected final int D_MULT_100 = 20005;
  protected final int DIVIDE_BY_5 = 20006;
  protected final int DIVIDE_BY_3 = 20007;
  protected final int DIVIDE_BY_7 = 20008;

  final String[] mediumQuestions =
    {
      "What is the Result of (A + E)?",
      "What is the Result of (B + D)?",
      "What is the Result of (B + 27)?",
      "What is the Result of (C * 10)?",
      "What is the Result of (D / 100)?",
      "Which number is divisible by 5?",
      "Which number is divisible by 3?",
      "Which number is divisible by 7?",
    };

  final int[] mediumQuestionsInNumber = {A_PLUS_E, B_PLUS_D, B_PLUS_27, C_MULT_10, D_MULT_100, DIVIDE_BY_5, DIVIDE_BY_3, DIVIDE_BY_7};

  protected final int FACTORIAL_A = 30001;
  protected final int SQUAREROOT_C = 30002;
  protected final int FACTORIAL_B_PLUS_D = 30003;
  protected final int A_PLUS_E_MULT_C_PLUS_B = 30004;
  protected final int B_PLUS_E_MULT_B_PLUS_E = 30005;
  protected final int A_MINUS_C_MULT_A_MINUS_C = 30006;
  protected final int A_PLUS_B_MULT_A_MINUS_B = 30007;
  protected final int FORMULA_LAST = 30008;

  final String[] toughQuestions =
    {
      "Which is the result of factorial(A) ?",
      "Which is the result of SquareRoot(C) ?",
      "Which is the result of factorial(B + D) ?",
      "Which is the result of (A + E) * (C + B) ?",
      "Which is the result of (B + E) * (B + E) ?",
      "Which is the result of (A - C) * (A - C) ?",
      "Which is the result of (A + B) * (A - B) ?",
      "Which is the result of ((A + B) * (C + D)) / (A * 10)",
    };

  final int[] toughQuestionsInNumber = {FACTORIAL_A, SQUAREROOT_C, FACTORIAL_B_PLUS_D, A_PLUS_E_MULT_C_PLUS_B, B_PLUS_E_MULT_B_PLUS_E, A_MINUS_C_MULT_A_MINUS_C, A_PLUS_B_MULT_A_MINUS_B, FORMULA_LAST};

  protected int switchToTurnOn = 0;
  protected int selectedQuestionIndex = 0;
  protected int numberOfAteempts = 0;
  @Override
  protected void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_final_question);

    Intent intent = getIntent();
    ageGroup = intent.getIntExtra(CodesLayout.AGE_GROUP_KEY, 0);
    switchSelected = intent.getIntExtra(CodesLayout.SELECTED_SWITCH_KEY, 0);

    int age = 0;
    UpdateQuestion(age);

    aVal = new Random().nextInt(1001) + 20;
    bVal = new Random().nextInt(1001) + 20;
    cVal = new Random().nextInt(1001) + 20;
    dVal = new Random().nextInt(1001) + 20;
    eVal = new Random().nextInt(1001) + 20;

    TextView textA_Value = (TextView)findViewById(R.id.textA_Value);
    textA_Value.setText(Integer.toString(aVal));

    TextView textB_Value = (TextView)findViewById(R.id.textB_Value);
    textB_Value.setText(Integer.toString(bVal));

    TextView textC_Value = (TextView)findViewById(R.id.textC_Value);
    textC_Value.setText(Integer.toString(cVal));

    TextView textD_Value = (TextView)findViewById(R.id.textD_Value);
    textD_Value.setText(Integer.toString(dVal));

    TextView textE_Value = (TextView)findViewById(R.id.textE_Value);
    textE_Value.setText(Integer.toString(eVal));

    Button buttonFinish = (Button)findViewById(R.id.buttonFinish);
    buttonFinish.setOnClickListener(new View.OnClickListener()
    {
      @Override
      public void onClick(View v)
      {
        ValidateGivenAnswer();
      }
    });
  }

  protected void UpdateQuestion(int age)
  {
    int selecteduestionIndex_ = new Random().nextInt(9);
    String selectedQuestion = simpleQuestions[0];
    selectedQuestionIndex = simpleQuestionsInNumber[0];

    //TODO : Enable when all functions are implemented
    /*
    switch (age)
    {
      case 1:
        selectedQuestion = simpleQuestions[selecteduestionIndex_];
        selectedQuestionIndex = simpleQuestionsInNumber[selecteduestionIndex_];
        break;

      case 2:
      case 3:
        selectedQuestion = mediumQuestions[selecteduestionIndex_];
        selectedQuestionIndex = mediumQuestionsInNumber[selecteduestionIndex_];
        break;

      case 4:
        selectedQuestion = toughQuestions[selecteduestionIndex_];
        selectedQuestionIndex = toughQuestionsInNumber[selecteduestionIndex_];
        break;

      default:
        break;
    }*/

    TextView textQuestion = (TextView)(findViewById(R.id.textQuestion));
    textQuestion.setText(selectedQuestion);
  }

  public void ShowAlertDialog()
  {
    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
    alertDialogBuilder.setMessage("Answer is Wrong");
    alertDialogBuilder.setPositiveButton(R.string.ok_button_label, new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface dialog, int whichButton)
      {
        dialog.dismiss();
      }
    }).show();
  }

  public void ShowFailedDialog()
  {
    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
    alertDialogBuilder.setMessage("Maximum Attempts Completed");
    alertDialogBuilder.setPositiveButton(R.string.ok_button_label, new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface dialog, int whichButton)
      {
        dialog.dismiss();
      }
    }).show();
  }

  protected void CompareWithNumber(int expectedValue)
  {
    EditText editTextAnswer = (EditText) findViewById(R.id.editTextAnswer);
    if(Integer.parseInt(editTextAnswer.getText().toString()) == expectedValue)
    {
      Intent intent = new Intent(this, AndroidClient.class);
      intent.putExtra(SWITCH_TO_TURN_ON, switchSelected);

      setResult(RESULT_OK, intent);
      finish();
    }
    else
    {
      numberOfAteempts++;
      ShowAlertDialog();

      if(numberOfAteempts >= 2)
      {
        ShowFailedDialog();

        Intent intent = new Intent(this, AndroidClient.class);
        intent.putExtra(SWITCH_TO_TURN_ON, 0);

        setResult(RESULT_OK, intent);
        finish();
      }
    }
  }

  protected void BiggestNumber()
  {
    int bigNum = aVal;
    if(bVal > bigNum)
    {
      bigNum = bVal;
    }

    if(cVal > bigNum)
    {
      bigNum = cVal;
    }

    if(dVal > bigNum)
    {
      bigNum = dVal;
    }

    if(eVal > bigNum)
    {
      bigNum = eVal;
    }

    CompareWithNumber(bigNum);
  }

  //TODO: Add remaining functions

  protected void ValidateGivenAnswer()
  {
    switch (selectedQuestionIndex)
    {
      case BIGGEST_NUMBER:
        BiggestNumber();
        break;

      case SMALLEST_NUMBER:
        break;

      case BIGGEST_BETWEEN_A_E:
        break;

      case NUMBER_A:
        break;

      case NUMBER_B:
        break;

      case NUMBER_C:
        break;

      case NUMBER_D:
        break;

      case NUMBER_E:
        break;

      case A_PLUS_E:
        break;

      case B_PLUS_D:
        break;

      case B_PLUS_27:
        break;

      case C_MULT_10:
        break;

      case D_MULT_100:
        break;

      case DIVIDE_BY_5:
        break;

      case DIVIDE_BY_3:
        break;

      case DIVIDE_BY_7:
        break;

      case FACTORIAL_A:
        break;

      case SQUAREROOT_C:
        break;

      case FACTORIAL_B_PLUS_D:
        break;

      case A_PLUS_E_MULT_C_PLUS_B:
        break;

      case B_PLUS_E_MULT_B_PLUS_E:
        break;

      case A_MINUS_C_MULT_A_MINUS_C:
        break;

      case A_PLUS_B_MULT_A_MINUS_B:
        break;

      case FORMULA_LAST:
        break;
    }
  }
}
