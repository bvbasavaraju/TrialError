package com.example.basavarajubv.androidclient;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CodesLayout extends AppCompatActivity
{

  private final int SWITCH_BENGALURU_EYE    = 1;
  private final int SWITCH_SHIP_IN_CYCLONE  = 2;
  private final int SWITCH_SKY_SCREAMER     = 3;
  private final int SWITCH_ASTRO_ORBITER    = 4;
  private final int SWITCH_GALAXY_OF_LIGHTS = 5;

  private final String[] switch1Codes = { "R2210", "JB5602", "TB9965", "JB5012", "CH0756" };
  private final String[] switch2Codes = { "R2225", "JB3302", "TB5621", "JB4111", "CH3690" };
  private final String[] switch3Codes = { "R8952", "JB5622", "TB4521", "JB8999", "CH1470" };
  private final String[] switch4Codes = { "R7851", "JB4586", "TB5624", "JB7888", "CH7895" };
  private final String[] switch5Codes = { "R8520", "JB6452", "TB5554", "JB5666", "CH2580" };

  int ageGroup = 0;
  int switchSelected = 0;

  public static final String SELECTED_SWITCH_KEY = "com.example.basavarajubv.androidclient.SELECTED_SWITCH_KEY";
  public static final String AGE_GROUP_KEY = "com.example.basavarajubv.androidclient.AGE_GROUP_KEY";

  private EditText editTextJB1InputCode;
  private EditText editTextTB1InputCode;
  private EditText editTextJB2InputCode;
  private EditText editTextCH1InputCode;
  private EditText editTextCH1OutputCode;

  int numberOfAteempts = 0;

  @Override
  protected void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_codes_layout);

    Intent intent = getIntent();
    ageGroup = intent.getIntExtra(SwitchLayout.AGE_GROUP_KEY, 0);
    switchSelected = intent.getIntExtra(SwitchLayout.SELECTED_SWITCH_KEY, 0);

    numberOfAteempts = 0;

    editTextJB1InputCode = (EditText) findViewById(R.id.editTextJB1InputCode);
    editTextTB1InputCode = (EditText) findViewById(R.id.editTextTB1InputCode);
    editTextJB2InputCode = (EditText) findViewById(R.id.editTextJB2InputCode);
    editTextCH1InputCode = (EditText) findViewById(R.id.editTextCH1InputCode);
    editTextCH1OutputCode = (EditText) findViewById(R.id.editTextCH1OutputCode);

    Button buttonSwitch1 = (Button)(findViewById(R.id.buttonSubmit));
    buttonSwitch1.setOnClickListener(new View.OnClickListener()
    {
      @Override
      public void onClick(View v)
      {
        ValidateCodes();
      }
    });
  }

  protected void ValidateCodes()
  {
    switch (switchSelected)
    {
      case SWITCH_BENGALURU_EYE:
          CheckForCodes(switch1Codes);
        break;

      case SWITCH_SHIP_IN_CYCLONE:
          CheckForCodes(switch2Codes);
        break;

      case SWITCH_SKY_SCREAMER:
          CheckForCodes(switch3Codes);
        break;

      case SWITCH_ASTRO_ORBITER:
          CheckForCodes(switch4Codes);
        break;

      case SWITCH_GALAXY_OF_LIGHTS:
          CheckForCodes(switch5Codes);
        break;

      default:
        break;
    }

  }

  protected void CheckForCodes(String[] expectedCodes)
  {
    if( !(editTextJB1InputCode.getText().toString().equalsIgnoreCase(expectedCodes[0]))
        || !(editTextTB1InputCode.getText().toString().equalsIgnoreCase(expectedCodes[1]))
        || !(editTextJB2InputCode.getText().toString().equalsIgnoreCase(expectedCodes[2]))
        || !(editTextCH1InputCode.getText().toString().equalsIgnoreCase(expectedCodes[3]))
        || !(editTextCH1OutputCode.getText().toString().equalsIgnoreCase(expectedCodes[4]))
      )
    {
      ShowAlertDialog();
      numberOfAteempts++;
      if(numberOfAteempts >= 2)
      {
        ShowFailedDialog();

        Intent intent = new Intent(this, AndroidClient.class);
        setResult(RESULT_CANCELED, intent);

        finish();
      }
    }
    else
    {
      Intent intent = new Intent(this, FinalQuestionActivity.class);
      intent.putExtra(AGE_GROUP_KEY, ageGroup);
      intent.putExtra(SELECTED_SWITCH_KEY, switchSelected);

      startActivityForResult(intent, 1);
    }
  }

  public void ShowAlertDialog()
  {
    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
    alertDialogBuilder.setMessage("You have Entered Wrong Code");
    alertDialogBuilder.setPositiveButton(R.string.ok_button_label, new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface dialog, int whichButton)
      {
        dialog.dismiss();
      }
    }).show();
  }

  public void ShowFailedDialog()
  {
    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
    alertDialogBuilder.setMessage("Maximum Attempts Completed");
    alertDialogBuilder.setPositiveButton(R.string.ok_button_label, new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface dialog, int whichButton)
      {
        dialog.dismiss();
      }
    }).show();
  }

  public void onActivityResult(int requestCode, int resultCode, Intent data)
  {
    setResult(RESULT_OK, data);
    finish();
  }
}
